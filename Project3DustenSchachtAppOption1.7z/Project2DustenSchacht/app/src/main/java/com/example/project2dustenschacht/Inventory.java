package com.example.project2dustenschacht;

public class Inventory {
    private int id;
    private String Product;

    Inventory(String item) {
    }
    Inventory(int id, String Product) {
        this.id = id;
        this.Product = Product;
    }

    void setProductID(int id) {

        this.id = id;
    }
    int getProductID() {

        return this.id;
    }

    void setProductName(int id) {

        this.id = id;
    }

    int getProductName() {
        return this.id = id;
    }

    void setOnHands(int id) {
        this.id = id;
    }

    int getOnHands() {
        return this.id = id;
    }
}
