package com.example.project2dustenschacht;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.media.MediaRouter;


public class SQL extends SQLiteOpenHelper {
    SQLiteDatabase db= this.getReadableDatabase();


    // Table Name
    public static final String User_Names = "User Names";
    public static final String Inventory = "Inventory";

    // Table Columns
    public static final String _Name = "_Name";
    public static final String _UserId = "_Id";
    public static final String _Password = "_Password";
    public static final String _Product = "Product Name";
    public static final String _OnHands = "On hands";
    public static final String _ProductID = "Product ID";

    // DB
    static final String DB_NAME = "User_Info";
    static final String DB_Inventory = "Total Inventory";

    // database version
    static final int DB_VERSION = 1;

    // Creating table query
    private static final String CREATE_TABLE = "create table " + User_Names +  _UserId + _Name + _Password;
    private static final String CREATE_TABLE1 = "Create Table " + Inventory + _Product + _OnHands +  _ProductID;


    public SQL(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
        SQLiteDatabase db= this.getWritableDatabase();


    }



    @Override
    public void onCreate(SQLiteDatabase db)
    {
        db.execSQL(CREATE_TABLE);
        db.execSQL(CREATE_TABLE1);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("Drop Table " + User_Names);
        db.execSQL("Drop Table " + Inventory);
        onCreate(db);
    }

    String LoadUser() {
        String result = "";
        String query = "Select*FROM " + User_Names;
        SQLiteDatabase db= this.getWritableDatabase();
        Cursor cursor = db.rawQuery(query, null);
        while (cursor.moveToNext()) {
            int result_0 = cursor.getInt(0);
            String result_1 = cursor.getString(1);
            result += String.valueOf(result_0) + " " + result_1 + System.getProperty("line.separator");
        }
        cursor.close();
        db.close();
        if(result.equals(""))
            result="User not found";
        return result;
    }

    Long addUser(User user) {
        long id;
        ContentValues values = new ContentValues();
        values.put(_UserId, user.getId());
        values.put(_Name, user.getUser());
        values.put(_Password, user.getPassword());
        SQLiteDatabase db= this.getWritableDatabase();
        id = db.insert(User_Names, null, values);
        db.close();
        return id;
    }




    String LoadInventory() {
        String result = "";
        String query = "Select*FROM " + Inventory;
        SQLiteDatabase db= this.getWritableDatabase();
        Cursor cursor = db.rawQuery(query, null);
        while (cursor.moveToNext()) {
            int result_0 = cursor.getInt(0);
            String result_1 = cursor.getString(1);
            result += String.valueOf(result_0) + " " + result_1 + System.getProperty("line.separator");
        }
        cursor.close();
        db.close();
        if(result.equals(""))
            result="Item not found";
        return result;
    }

    Long addInventory(Inventory inv) {
        long id;
        ContentValues values = new ContentValues();
        values.put(_ProductID, inv.getProductID());
        values.put(_Product, inv.getProductName());
        values.put(_OnHands, inv.getOnHands());
        SQLiteDatabase db= this.getWritableDatabase();
        id = db.insert(Inventory, null, values);
        db.close();
        return id;
    }

    boolean UpdateInventory(int ID, String name) {
        SQLiteDatabase db= this.getWritableDatabase();
        ContentValues args = new ContentValues();
        args.put(_ProductID, ID);
        args.put(_Product, name);
        return db.update(Inventory, args, _ProductID + "=" + _Product, null) > 0;
    }

    boolean DeleteInventory(int ID) {
        boolean result = false;
        String query = "Select*FROM" + Inventory + " Where " + _Product + " = " + String.valueOf(ID) + "'";
        SQLiteDatabase db= this.getWritableDatabase();
        Cursor cursor = db.rawQuery(query, null);
        Inventory inv = new Inventory();
        if (cursor.moveToFirst()) {
            inv.setProductID(Integer.parseInt(cursor.getString(0)));
            db.delete(Inventory, _Product + "?",
                    new String[]{
                            String.valueOf(inv.getProductID())
                    });
            cursor.close();
            result = true;
        }
        db.close();
        return result;
    }

}


