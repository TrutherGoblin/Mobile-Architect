package com.example.project2dustenschacht;

public class User {
    private int id;
    private String User;

    User() {
    }
    User(int id,String User) {
        this.id = id;
        this.User = User;
    }
    void setId(int id) {
        this.id = id;
    }
    int getId() {
        return this.id;
    }
    void setUser(String User) {
        this.User = User;
    }
    String getUser() {
        return this.User;
    }
    void setPassword(String User) {
        this.id = id;
    }
    int getPassword() {
        return this.id;
    }
}
