package com.example.project2dustenschacht;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class Class2 extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.Oncreate(SavedInstanceState);
        setContentView(R.layout.activity_main);
    }
}
