package com.example.project2dustenschacht;
import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.EditText;
import android.widget.Button;
import android.view.View;
import android.text.method.ScrollingMovementMethod;
import com.google.android.material.snackbar.Snackbar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;
import com.example.project2dustenschacht.databinding.ActivityMainBinding;
import android.content.Intent;
import android.telephony.SmsManager;
import android.util.Log;
import android.view.Menu;
import android.view.Menu;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    public Button button;
    private static final int PermissionRequest =0 ;


    EditText UserName;
    EditText Password;
    EditText Onhands1;
    EditText Onhands2;
    EditText Onhands3;
    EditText Onhands4;
    EditText Onhands5;
    EditText Onhands6;
    EditText Onhands7;
    EditText Onhands8;
    EditText Onhands9;
    EditText Onhands10;
    TextView Item_1;
    TextView Item_2;
    TextView Item_3;
    TextView Item_4;
    TextView Item_5;
    TextView Item_6;
    TextView Item_7;
    TextView Item_8;
    TextView Item_9;
    TextView Item_10;
    TextView resultText;
    TextView resultText1;
    SQL sql;




    private AppBarConfiguration appBarConfiguration;
    private ActivityMainBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Password = (EditText) findViewById(R.id.password);
        UserName = (EditText) findViewById(R.id.username);
        Onhands1 = (EditText) findViewById(R.id.OnHands1);
        Onhands2 = (EditText) findViewById(R.id.OnHands2);
        Onhands3 = (EditText) findViewById(R.id.OnHands3);
        Onhands4 = (EditText) findViewById(R.id.OnHands4);
        Onhands5 = (EditText) findViewById(R.id.OnHands5);
        Onhands6 = (EditText) findViewById(R.id.OnHands6);
        Onhands7 = (EditText) findViewById(R.id.OnHands7);
        Onhands8 = (EditText) findViewById(R.id.OnHands8);
        Onhands9 = (EditText) findViewById(R.id.OnHands9);
        Onhands10 = (EditText) findViewById(R.id.OnHands10);
        Item_1 = (TextView) findViewById(R.id.Item1);
        Item_2 = (TextView) findViewById(R.id.Item2);
        Item_3 = (TextView) findViewById(R.id.Item3);
        Item_4 = (TextView) findViewById(R.id.Item4);
        Item_5 = (TextView) findViewById(R.id.Item5);
        Item_6 = (TextView) findViewById(R.id.Item6);
        Item_7 = (TextView) findViewById(R.id.Item7);
        Item_8 = (TextView) findViewById(R.id.Item8);
        Item_9 = (TextView) findViewById(R.id.Item9);
        Item_10 = (TextView) findViewById(R.id.Item10);
        resultText = (TextView) findViewById(R.id.Result);
        resultText1 = (TextView) findViewById(R.id.Result1);
        button = (Button) findViewById(R.id.login);
        sql = new SQL(this);


        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        setSupportActionBar(binding.toolbar);

        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_content_main);
        appBarConfiguration = new AppBarConfiguration.Builder(navController.getGraph()).build();
        NavigationUI.setupActionBarWithNavController(this, navController, appBarConfiguration);
    }

    public void addUser(View view) {
        if (!UserName.getText().toString().isEmpty() && !Password.getText().toString().isEmpty()) {
            int password = Integer.parseInt(UserName.getText().toString());
            String username = Password.getText().toString();
            User user = new User(password, username);
            long insertId = sql.addUser(user);
            if (insertId == -1) {
                // login
                resultText.setText("Welcome User");
                button.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Intent intent = new Intent(MainActivity.this, Class2.class);
                        startActivity(intent);
                    }
                });
            }




            //added user
            else {
                Password.setText("");
                UserName.setText("");
                resultText.setText("User added");
            }
        } else {

            // incorrect user
            resultText.setText("Incorrect Username or Password");
        }
    }

    public void loadInventory(View view) {
        Item_1.setText(sql.LoadInventory());
        Item_2.setText(sql.LoadInventory());
        Item_3.setText(sql.LoadInventory());
        Item_4.setText(sql.LoadInventory());
        Item_5.setText(sql.LoadInventory());
        Item_6.setText(sql.LoadInventory());
        Item_7.setText(sql.LoadInventory());
        Item_8.setText(sql.LoadInventory());
        Item_9.setText(sql.LoadInventory());
        Item_10.setText(sql.LoadInventory());
    }

    public void addInventory(View view) {
        if (!Item_1.getText().toString().isEmpty());
        String item = Item_1.getText().toString();
        Inventory inventory = new Inventory(item);
        long insertId = sql.addInventory(inventory);
        if (insertId == -1) {
            resultText1.setText("Item already exists");
        } else {
            item.setText("");
            resultText1.setText("Record added");
        }
    }

    public void deleteInventory(View view) {
        if (!Item_1.getText().toString().isEmpty()) {
            boolean result = sql.DeleteInventory(Integer.parseInt(
                    Item_1.getText().toString()));
            if (result) {
                Item_1.setText("");
                resultText.setText("Item Deleted");
            } else {
                resultText.setText("Item not Found");
            }
        }
    }

    public void Message(CharSequence text, short timestamp) {
        if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            if (ActivityCompat.shouldShowRequestPermissionRationale(this,
                    Manifest.permission.SEND_SMS)) {
            } else {
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.SEND_SMS},
                        PermissionRequest);
            }
        }
    }
}









